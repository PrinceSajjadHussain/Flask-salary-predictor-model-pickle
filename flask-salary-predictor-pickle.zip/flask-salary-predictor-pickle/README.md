# flask-salary-predictor
This is project predicts the salary of the employee based on the experience.

# Model
model.py trains and saves the model to the disk.
model.pkb the pickle model 

# App
app.py contains all the requiered for flask and to manage APIs.



Procedure--
Open command Prompt and go to given directory and then run python app.py
